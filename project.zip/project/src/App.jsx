import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import LandingPage from './pages/LandingPage.jsx';
import CustomerLogin from './pages/CustomerLogin.jsx';
import CustomerRegister from './pages/CustomerRegister.jsx';
import RestaurantLogin from './pages/RestaurantLogin.jsx';
import RestaurantRegister from './pages/RestaurantRegister.jsx';
import RestaurantDashboard from './pages/RestaurantDashboard.jsx';
import MainPage from './pages/MainPage.jsx';
import RestaurantPage from './pages/RestaurantPage.jsx';
import CartPage from './pages/CartPage.jsx';
import PaymentPage from './pages/PaymentPage.jsx';
import PaymentSuccess from './pages/PaymentSuccess.jsx';
import UserProfile from './pages/UserProfile.jsx';

function App() {
  return (
    <AppProvider>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/customer/login" element={<CustomerLogin />} />
          <Route path="/customer/register" element={<CustomerRegister />} />
          <Route path="/restaurant/login" element={<RestaurantLogin />} />
          <Route path="/restaurant/register" element={<RestaurantRegister />} />
          
          {/* Protected Routes - Customer Only */}
          <Route path="/main" element={
            <ProtectedRoute>
              <MainPage />
            </ProtectedRoute>
          } />
          <Route path="/restaurant/:id" element={
            <ProtectedRoute>
              <RestaurantPage />
            </ProtectedRoute>
          } />
          <Route path="/cart" element={
            <ProtectedRoute requiredRole="customer">
              <CartPage />
            </ProtectedRoute>
          } />
          <Route path="/payment" element={
            <ProtectedRoute requiredRole="customer">
              <PaymentPage />
            </ProtectedRoute>
          } />
          <Route path="/payment/success" element={
            <ProtectedRoute requiredRole="customer">
              <PaymentSuccess />
            </ProtectedRoute>
          } />
          <Route path="/profile" element={
            <ProtectedRoute>
              <UserProfile />
            </ProtectedRoute>
          } />
          
          {/* Protected Routes - Restaurant Only */}
          <Route path="/restaurant/dashboard" element={
            <ProtectedRoute requiredRole="restaurant">
              <RestaurantDashboard />
            </ProtectedRoute>
          } />
        </Routes>
      </div>
    </AppProvider>
  );
}

export default App;