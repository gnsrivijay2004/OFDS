import React, { createContext, useContext, useReducer } from 'react';

const AppContext = createContext();

const initialState = {
  user: null,
  userType: null, // 'customer' or 'restaurant'
  cart: [],
  cartRestaurant: null,
  restaurants: [
    {
      id: 1,
      name: "Spice Garden",
      location: "Downtown",
      email: "spice@garden.com",
      menu: [
        { id: 1, name: "Chicken Biryani", isVeg: false, price: 250, description: "Aromatic basmati rice with tender chicken" },
        { id: 2, name: "Paneer Butter Masala", isVeg: true, price: 200, description: "Rich and creamy paneer curry" },
        { id: 3, name: "Dal Tadka", isVeg: true, price: 150, description: "Traditional lentil curry with spices" }
      ]
    },
    {
      id: 2,
      name: "Pizza Palace",
      location: "Central Plaza",
      email: "info@pizzapalace.com",
      menu: [
        { id: 4, name: "Margherita Pizza", isVeg: true, price: 300, description: "Classic pizza with tomato and mozzarella" },
        { id: 5, name: "Pepperoni Pizza", isVeg: false, price: 400, description: "Loaded with pepperoni and cheese" },
        { id: 6, name: "Garlic Bread", isVeg: true, price: 120, description: "Crispy bread with garlic butter" }
      ]
    },
    {
      id: 3,
      name: "Burger Junction",
      location: "Mall Road",
      email: "hello@burgerjunction.com",
      menu: [
        { id: 7, name: "Classic Burger", isVeg: false, price: 180, description: "Beef patty with lettuce and tomato" },
        { id: 8, name: "Veggie Burger", isVeg: true, price: 160, description: "Plant-based patty with fresh vegetables" },
        { id: 9, name: "Chicken Wings", isVeg: false, price: 220, description: "Spicy grilled chicken wings" }
      ]
    }
  ],
  orders: [],
  currentRestaurant: null
};

function appReducer(state, action) {
  switch (action.type) {
    case 'LOGIN':
      return {
        ...state,
        user: action.payload.user,
        userType: action.payload.userType
      };
    case 'LOGOUT':
      return {
        ...state,
        user: null,
        userType: null,
        cart: [],
        cartRestaurant: null
      };
    case 'ADD_TO_CART':
      const { item, restaurant } = action.payload;
      if (state.cartRestaurant && state.cartRestaurant.id !== restaurant.id) {
        // Can't add from different restaurant
        return state;
      }
      
      const existingItem = state.cart.find(cartItem => cartItem.id === item.id);
      if (existingItem) {
        return {
          ...state,
          cart: state.cart.map(cartItem =>
            cartItem.id === item.id
              ? { ...cartItem, quantity: cartItem.quantity + 1 }
              : cartItem
          )
        };
      } else {
        return {
          ...state,
          cart: [...state.cart, { ...item, quantity: 1 }],
          cartRestaurant: state.cartRestaurant || restaurant
        };
      }
    case 'REMOVE_FROM_CART':
      const updatedCart = state.cart.map(cartItem =>
        cartItem.id === action.payload.id
          ? { ...cartItem, quantity: cartItem.quantity - 1 }
          : cartItem
      ).filter(cartItem => cartItem.quantity > 0);
      
      return {
        ...state,
        cart: updatedCart,
        cartRestaurant: updatedCart.length === 0 ? null : state.cartRestaurant
      };
    case 'CLEAR_CART':
      return {
        ...state,
        cart: [],
        cartRestaurant: null
      };
    case 'ADD_ORDER':
      return {
        ...state,
        orders: [action.payload, ...state.orders]
      };
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.payload.orderId
            ? { ...order, status: action.payload.status }
            : order
        )
      };
    case 'SET_CURRENT_RESTAURANT':
      return {
        ...state,
        currentRestaurant: action.payload
      };
    case 'ADD_MENU_ITEM':
      return {
        ...state,
        restaurants: state.restaurants.map(restaurant =>
          restaurant.id === action.payload.restaurantId
            ? {
                ...restaurant,
                menu: [...restaurant.menu, { ...action.payload.item, id: Date.now() }]
              }
            : restaurant
        )
      };
    case 'UPDATE_MENU_ITEM':
      return {
        ...state,
        restaurants: state.restaurants.map(restaurant =>
          restaurant.id === action.payload.restaurantId
            ? {
                ...restaurant,
                menu: restaurant.menu.map(item =>
                  item.id === action.payload.item.id ? action.payload.item : item
                )
              }
            : restaurant
        )
      };
    case 'DELETE_MENU_ITEM':
      return {
        ...state,
        restaurants: state.restaurants.map(restaurant =>
          restaurant.id === action.payload.restaurantId
            ? {
                ...restaurant,
                menu: restaurant.menu.filter(item => item.id !== action.payload.itemId)
              }
            : restaurant
        )
      };
    case 'SET_RESTAURANTS':
      return {
        ...state,
        restaurants: action.payload
      };
    case 'SET_CART':
      return {
        ...state,
        cart: action.payload.items || [],
        cartRestaurant: action.payload.restaurant
      };
    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}