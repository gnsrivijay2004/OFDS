import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { authService } from '../services/authService';

const AppContext = createContext();

const initialState = {
  user: null,
  userType: null, // 'customer' or 'restaurant'
  isAuthenticated: false,
  cart: [],
  cartRestaurant: null,
  restaurants: [], // Start with empty array - will be populated from backend
  orders: [],
  currentRestaurant: null
};

function appReducer(state, action) {
  switch (action.type) {
    case 'LOGIN':
      return {
        ...state,
        user: action.payload.user,
        userType: action.payload.userType,
        isAuthenticated: true
      };
    case 'LOGOUT':
      return {
        ...state,
        user: null,
        userType: null,
        isAuthenticated: false,
        cart: [],
        cartRestaurant: null
      };
    case 'INIT_AUTH':
      return {
        ...state,
        user: action.payload.user,
        userType: action.payload.userType,
        isAuthenticated: action.payload.isAuthenticated
      };
    case 'ADD_TO_CART':
      const { item, restaurant } = action.payload;
      if (state.cartRestaurant && state.cartRestaurant.id !== restaurant.id) {
        // Can't add from different restaurant
        return state;
      }
      
      const existingItem = state.cart.find(cartItem => cartItem.id === item.id);
      if (existingItem) {
        return {
          ...state,
          cart: state.cart.map(cartItem =>
            cartItem.id === item.id
              ? { ...cartItem, quantity: cartItem.quantity + 1 }
              : cartItem
          )
        };
      } else {
        return {
          ...state,
          cart: [...state.cart, { ...item, quantity: 1 }],
          cartRestaurant: state.cartRestaurant || restaurant
        };
      }
    case 'REMOVE_FROM_CART':
      const updatedCart = state.cart.map(cartItem =>
        cartItem.id === action.payload.id
          ? { ...cartItem, quantity: cartItem.quantity - 1 }
          : cartItem
      ).filter(cartItem => cartItem.quantity > 0);
      
      return {
        ...state,
        cart: updatedCart,
        cartRestaurant: updatedCart.length === 0 ? null : state.cartRestaurant
      };
    case 'CLEAR_CART':
      return {
        ...state,
        cart: [],
        cartRestaurant: null
      };
    case 'ADD_ORDER':
      return {
        ...state,
        orders: [action.payload, ...state.orders]
      };
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.payload.orderId
            ? { ...order, status: action.payload.status }
            : order
        )
      };
    case 'SET_CURRENT_RESTAURANT':
      return {
        ...state,
        currentRestaurant: action.payload
      };
    case 'ADD_MENU_ITEM':
      return {
        ...state,
        restaurants: state.restaurants.map(restaurant =>
          restaurant.id === action.payload.restaurantId
            ? {
                ...restaurant,
                menu: [...restaurant.menu, { ...action.payload.item, id: Date.now() }]
              }
            : restaurant
        )
      };
    case 'UPDATE_MENU_ITEM':
      return {
        ...state,
        restaurants: state.restaurants.map(restaurant =>
          restaurant.id === action.payload.restaurantId
            ? {
                ...restaurant,
                menu: restaurant.menu.map(item =>
                  item.id === action.payload.item.id ? action.payload.item : item
                )
              }
            : restaurant
        )
      };
    case 'DELETE_MENU_ITEM':
      return {
        ...state,
        restaurants: state.restaurants.map(restaurant =>
          restaurant.id === action.payload.restaurantId
            ? {
                ...restaurant,
                menu: restaurant.menu.filter(item => item.id !== action.payload.itemId)
              }
            : restaurant
        )
      };
    case 'SET_RESTAURANTS':
      return {
        ...state,
        restaurants: action.payload
      };
    case 'SET_CART':
      return {
        ...state,
        cart: action.payload.items || [],
        cartRestaurant: action.payload.restaurant
      };
    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Check for existing authentication on app startup
  useEffect(() => {
    const initializeAuth = () => {
      const isAuthenticated = authService.isAuthenticated();
      const userType = authService.getUserType();
      
      if (isAuthenticated && userType) {
        // User has a valid token, initialize the auth state
        dispatch({
          type: 'INIT_AUTH',
          payload: {
            user: { email: 'user@example.com', name: userType === 'customer' ? 'Customer' : 'Restaurant' },
            userType: userType,
            isAuthenticated: true
          }
        });
      }
    };

    initializeAuth();
  }, []);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}