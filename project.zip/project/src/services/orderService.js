import axiosClient from './axiosClient';

export const orderService = {
  // Place order
  placeOrder: async (orderData) => {
    const idempotencyKey = `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const response = await axiosClient.post('/api/orders', orderData, {
      headers: {
        'Idempotency-Key': idempotencyKey
      }
    });
    return response.data;
  },

  // Get user orders
  getUserOrders: async () => {
    const response = await axiosClient.get('/api/orders/user');
    return response.data;
  },

  // Get restaurant orders
  getRestaurantOrders: async (restaurantId) => {
    const response = await axiosClient.get(`/api/orders/restaurant/${restaurantId}`);
    return response.data;
  },

  // Update order status
  updateOrderStatus: async (orderId, status) => {
    const response = await axiosClient.put(`/api/orders/${orderId}/status`, { status });
    return response.data;
  },

  // Get order details
  getOrderDetails: async (orderId) => {
    const response = await axiosClient.get(`/api/orders/${orderId}`);
    return response.data;
  }
}; 