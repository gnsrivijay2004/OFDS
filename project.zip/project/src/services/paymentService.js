import axiosClient from './axiosClient';

export const paymentService = {
  // Initiate payment
  initiatePayment: async (paymentData) => {
    const response = await axiosClient.post('/api/payments/initiate', paymentData);
    return response.data;
  },

  // Confirm payment
  confirmPayment: async (paymentData) => {
    const response = await axiosClient.put('/api/payments/confirm', paymentData);
    return response.data;
  },

  // Get payment for order
  getPaymentForOrder: async (orderId) => {
    const response = await axiosClient.get(`/api/payments/order/${orderId}`);
    return response.data;
  }
}; 