import axiosClient from './axiosClient';

export const authService = {
  // Customer login
  customerLogin: async (credentials) => {
    const response = await axiosClient.post('/api/auth/customer/login', credentials);
    if (response.data.jwtToken) {
      localStorage.setItem('jwtToken', response.data.jwtToken);
      localStorage.setItem('userType', 'customer');
    }
    return response.data;
  },

  // Restaurant login
  restaurantLogin: async (credentials) => {
    const response = await axiosClient.post('/api/auth/restaurant/login', credentials);
    if (response.data.jwtToken) {
      localStorage.setItem('jwtToken', response.data.jwtToken);
      localStorage.setItem('userType', 'restaurant');
    }
    return response.data;
  },

  // Customer registration
  customerRegister: async (userData) => {
    const response = await axiosClient.post('/api/customers/register', userData);
    return response.data;
  },

  // Restaurant registration
  restaurantRegister: async (restaurantData) => {
    const response = await axiosClient.post('/api/restaurants/register', restaurantData);
    return response.data;
  },

  // Logout
  logout: () => {
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('userType');
  },

  // Check if user is authenticated
  isAuthenticated: () => {
    return !!localStorage.getItem('jwtToken');
  },

  // Get user type
  getUserType: () => {
    return localStorage.getItem('userType');
  },

  // Get token
  getToken: () => {
    return localStorage.getItem('jwtToken');
  }
}; 