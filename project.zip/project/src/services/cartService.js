import axiosClient from './axiosClient';

export const cartService = {
  // Get cart
  getCart: async () => {
    const response = await axiosClient.get('/api/cart');
    return response.data;
  },

  // Add item to cart
  addItemToCart: async (itemData) => {
    const response = await axiosClient.post('/api/cart/items', itemData);
    return response.data;
  },

  // Update cart item
  updateCartItem: async (itemId, itemData) => {
    const response = await axiosClient.put(`/api/cart/items/${itemId}`, itemData);
    return response.data;
  },

  // Remove item from cart
  removeItemFromCart: async (itemId) => {
    const response = await axiosClient.delete(`/api/cart/items/${itemId}`);
    return response.data;
  },

  // Clear cart
  clearCart: async () => {
    const response = await axiosClient.delete('/api/cart');
    return response.data;
  }
}; 