import axiosClient from './axiosClient';

export const menuService = {
  // Add menu item
  addMenuItem: async (menuItemData) => {
    const response = await axiosClient.post('/api/menu/restaurant', menuItemData);
    return response.data;
  },

  // Update menu item
  updateMenuItem: async (itemId, menuItemData) => {
    const response = await axiosClient.put(`/api/menu/${itemId}`, menuItemData);
    return response.data;
  },

  // Delete menu item
  deleteMenuItem: async (itemId) => {
    const response = await axiosClient.delete(`/api/menu/${itemId}`);
    return response.data;
  },

  // Get menu item by ID
  getMenuItemById: async (itemId) => {
    const response = await axiosClient.get(`/api/menu/${itemId}`);
    return response.data;
  }
}; 