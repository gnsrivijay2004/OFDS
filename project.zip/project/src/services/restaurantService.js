import axiosClient from './axiosClient';

export const restaurantService = {
  // Get all restaurants
  getAllRestaurants: async () => {
    const response = await axiosClient.get('/api/restaurants');
    return response.data;
  },

  // Get restaurant by ID
  getRestaurantById: async (id) => {
    const response = await axiosClient.get(`/api/restaurants/${id}`);
    return response.data;
  },

  // Get restaurant menu
  getRestaurantMenu: async (restaurantId) => {
    const response = await axiosClient.get(`/api/menu/restaurant/${restaurantId}`);
    return response.data;
  }
}; 