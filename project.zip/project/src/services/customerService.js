import axiosClient from './axiosClient';

export const customerService = {
  // Get customer profile
  getProfile: async () => {
    const response = await axiosClient.get('/api/customers/user');
    return response.data;
  },

  // Update customer profile
  updateProfile: async (profileData) => {
    const response = await axiosClient.put('/api/customers/user', profileData);
    return response.data;
  }
}; 