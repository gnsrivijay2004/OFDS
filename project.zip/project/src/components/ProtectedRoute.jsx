import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const ProtectedRoute = ({ children, requiredRole = null }) => {
  const location = useLocation();
  const { state } = useApp();
  
  // Check if user is authenticated using AppContext state
  const isAuthenticated = state.isAuthenticated;
  
  if (!isAuthenticated) {
    // Redirect to login page with return URL
    return <Navigate to="/customer/login" state={{ from: location }} replace />;
  }
  
  // If role is required, check user role from AppContext
  if (requiredRole && state.userType !== requiredRole) {
    // Redirect to appropriate login page based on required role
    const loginPath = requiredRole === 'restaurant' ? '/restaurant/login' : '/customer/login';
    return <Navigate to={loginPath} state={{ from: location }} replace />;
  }
  
  return children;
};

export default ProtectedRoute; 