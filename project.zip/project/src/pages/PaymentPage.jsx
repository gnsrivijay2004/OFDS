import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, CreditCard, CheckCircle, Smartphone, Banknote } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { orderService } from '../services/orderService';
import { paymentService } from '../services/paymentService';

function PaymentPage() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const [agreed, setAgreed] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [upiId, setUpiId] = useState('');
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const subtotal = state.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  const deliveryFee = subtotal > 200 ? 0 : 30;
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + deliveryFee + tax;

  const handlePayment = async () => {
    if (!agreed) {
      alert('Please agree to the terms and conditions');
      return;
    }

    // Validate payment method specific fields
    if (paymentMethod === 'card') {
      if (!cardDetails.cardNumber || !cardDetails.expiryDate || !cardDetails.cvv || !cardDetails.cardholderName) {
        alert('Please fill in all card details');
        return;
      }
    } else if (paymentMethod === 'upi') {
      if (!upiId) {
        alert('Please enter your UPI ID');
        return;
      }
    }

    setLoading(true);
    setError('');

    try {
      // Create order with backend
      const orderData = {
        items: state.cart.map(item => ({
          itemId: item.id,
          quantity: item.quantity,
          price: item.price
        })),
        totalAmount: total,
        deliveryAddress: state.user?.address || 'Default address',
        paymentMethod: paymentMethod
      };

      const order = await orderService.placeOrder(orderData);
      
      // Initiate payment if not COD
      if (paymentMethod !== 'cod') {
        const paymentData = {
          orderId: order.id,
          amount: total,
          paymentMethod: paymentMethod,
          paymentDetails: paymentMethod === 'card' ? cardDetails : { upiId: upiId }
        };
        
        await paymentService.initiatePayment(paymentData);
      }

      // Clear cart after successful order
      dispatch({ type: 'CLEAR_CART' });
      
      navigate('/payment/success', { state: { orderId: order.id, total, paymentMethod } });
    } catch (err) {
      setError(err.response?.data?.message || 'Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCardInputChange = (e) => {
    setCardDetails({
      ...cardDetails,
      [e.target.name]: e.target.value
    });
  };

  if (state.cart.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 d-flex align-items-center justify-content-center">
        <div className="text-center">
          <h2 className="h3 fw-bold text-gray-900 mb-3">No items in cart</h2>
          <Link to="/main" className="text-orange-500 text-decoration-none">
            Go back to main page
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container-fluid">
          <div className="d-flex align-items-center py-3">
            <Link 
              to="/cart" 
              className="btn btn-link p-2 text-gray-600 text-decoration-none me-3"
              style={{ borderRadius: '0.5rem' }}
            >
              <ArrowLeft size={24} />
            </Link>
            <h1 className="h3 fw-bold text-gray-900 mb-0">Payment</h1>
          </div>
        </div>
      </header>

      <div className="container py-4" style={{ maxWidth: '80rem' }}>
        {error && (
          <div className="alert alert-danger mb-4" role="alert">
            {error}
          </div>
        )}
        
        <div className="row g-4">
          {/* Payment Details */}
          <div className="col-lg-8">
            <div className="bg-white rounded-xl shadow-custom p-4">
              <h2 className="h4 fw-bold text-gray-900 mb-4">Payment Method</h2>

              {/* Payment Method Selection */}
              <div className="space-y-4 mb-4">
                {/* Card Payment */}
                <div className={`border rounded p-3 cursor-pointer transition-all ${
                  paymentMethod === 'card' ? 'border-orange-500 bg-orange-50' : 'border-gray-200'
                }`} onClick={() => setPaymentMethod('card')} style={{ cursor: 'pointer' }}>
                  <div className="d-flex align-items-center">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="card"
                      checked={paymentMethod === 'card'}
                      onChange={() => setPaymentMethod('card')}
                      className="form-check-input me-3"
                    />
                    <CreditCard className="text-primary me-2" size={24} />
                    <div>
                      <h6 className="fw-semibold text-gray-900 mb-0">Credit/Debit Card</h6>
                      <p className="small text-gray-600 mb-0">Pay securely with your card</p>
                    </div>
                  </div>
                </div>

                {/* UPI Payment */}
                <div className={`border rounded p-3 cursor-pointer transition-all ${
                  paymentMethod === 'upi' ? 'border-orange-500 bg-orange-50' : 'border-gray-200'
                }`} onClick={() => setPaymentMethod('upi')} style={{ cursor: 'pointer' }}>
                  <div className="d-flex align-items-center">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="upi"
                      checked={paymentMethod === 'upi'}
                      onChange={() => setPaymentMethod('upi')}
                      className="form-check-input me-3"
                    />
                    <Smartphone className="text-purple-500 me-2" size={24} />
                    <div>
                      <h6 className="fw-semibold text-gray-900 mb-0">UPI Payment</h6>
                      <p className="small text-gray-600 mb-0">Pay using UPI ID or QR code</p>
                    </div>
                  </div>
                </div>

                {/* Cash on Delivery */}
                <div className={`border rounded p-3 cursor-pointer transition-all ${
                  paymentMethod === 'cod' ? 'border-orange-500 bg-orange-50' : 'border-gray-200'
                }`} onClick={() => setPaymentMethod('cod')} style={{ cursor: 'pointer' }}>
                  <div className="d-flex align-items-center">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="cod"
                      checked={paymentMethod === 'cod'}
                      onChange={() => setPaymentMethod('cod')}
                      className="form-check-input me-3"
                    />
                    <Banknote className="text-success me-2" size={24} />
                    <div>
                      <h6 className="fw-semibold text-gray-900 mb-0">Cash on Delivery</h6>
                      <p className="small text-gray-600 mb-0">Pay when your order arrives</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Method Forms */}
              {paymentMethod === 'card' && (
                <div className="space-y-4 mb-4">
                  <h6 className="fw-semibold text-gray-900 mb-3">Card Details</h6>
                  <div className="mb-3">
                    <label className="form-label fw-medium text-gray-700">
                      Card Number
                    </label>
                    <input
                      type="text"
                      name="cardNumber"
                      placeholder="1234 1234 1234 1234"
                      className="form-control"
                      value={cardDetails.cardNumber}
                      onChange={handleCardInputChange}
                    />
                  </div>
                  
                  <div className="row g-3">
                    <div className="col-6">
                      <label className="form-label fw-medium text-gray-700">
                        Expiry Date
                      </label>
                      <input
                        type="text"
                        name="expiryDate"
                        placeholder="MM/YY"
                        className="form-control"
                        value={cardDetails.expiryDate}
                        onChange={handleCardInputChange}
                      />
                    </div>
                    <div className="col-6">
                      <label className="form-label fw-medium text-gray-700">
                        CVV
                      </label>
                      <input
                        type="text"
                        name="cvv"
                        placeholder="123"
                        className="form-control"
                        value={cardDetails.cvv}
                        onChange={handleCardInputChange}
                      />
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="form-label fw-medium text-gray-700">
                      Cardholder Name
                    </label>
                    <input
                      type="text"
                      name="cardholderName"
                      placeholder="Enter name on card"
                      className="form-control"
                      value={cardDetails.cardholderName}
                      onChange={handleCardInputChange}
                    />
                  </div>
                </div>
              )}

              {paymentMethod === 'upi' && (
                <div className="space-y-4 mb-4">
                  <h6 className="fw-semibold text-gray-900 mb-3">UPI Details</h6>
                  <div className="mb-3">
                    <label className="form-label fw-medium text-gray-700">
                      UPI ID
                    </label>
                    <input
                      type="text"
                      placeholder="yourname@upi"
                      className="form-control"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                    />
                  </div>
                  <div className="alert alert-info d-flex align-items-center">
                    <Smartphone className="text-purple-500 me-2" size={20} />
                    <div>
                      <div className="fw-medium text-purple-800 mb-1">Quick UPI Payment</div>
                      <p className="small text-purple-700 mb-0">
                        You'll be redirected to your UPI app to complete the payment securely.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'cod' && (
                <div className="space-y-4 mb-4">
                  <h6 className="fw-semibold text-gray-900 mb-3">Cash on Delivery</h6>
                  <div className="alert alert-success d-flex align-items-center">
                    <Banknote className="text-success me-2" size={20} />
                    <div>
                      <div className="fw-medium text-green-800 mb-1">Pay at Your Doorstep</div>
                      <p className="small text-green-700 mb-1">
                        Pay ₹{total} in cash when your order is delivered.
                      </p>
                      <p className="small text-green-600 mb-0">
                        Please keep exact change ready for a smooth delivery experience.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Order Summary */}
              <div className="bg-gray-50 rounded p-3 mb-4">
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <span className="fw-semibold text-gray-700">Order ID:</span>
                  <span className="fw-medium text-gray-900">{orderId}</span>
                </div>
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <span className="fw-semibold text-gray-700">Customer:</span>
                  <span className="fw-medium text-gray-900">{state.user?.name || 'Customer'}</span>
                </div>
                <div className="d-flex justify-content-between align-items-center">
                  <span className="fw-semibold text-gray-700">Amount:</span>
                  <span className="fw-bold text-green-600 h5">₹{total}</span>
                </div>
              </div>

              {/* Terms and Conditions */}
              <div className="form-check p-3 bg-gray-50 rounded mb-4">
                <input
                  type="checkbox"
                  id="terms"
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                  className="form-check-input"
                />
                <label htmlFor="terms" className="form-check-label small text-gray-700">
                  I agree to the terms and conditions and authorize this payment. 
                  {paymentMethod === 'cod' && ' I understand that payment will be collected upon delivery.'}
                </label>
              </div>

              <button
                onClick={handlePayment}
                disabled={!agreed || loading}
                className={`btn w-100 fw-semibold transition-all ${
                  agreed && !loading
                    ? 'btn-orange transform-scale'
                    : 'btn-secondary disabled'
                }`}
              >
                {loading ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    Processing...
                  </>
                ) : (
                  paymentMethod === 'cod' ? 'Place Order' : `Pay ₹${total}`
                )}
              </button>
            </div>
          </div>

          {/* Order Summary */}
          <div className="col-lg-4">
            <div className="bg-white rounded-xl shadow-custom p-4">
              <h3 className="h5 fw-bold text-gray-900 mb-4">Order Summary</h3>
              
              {/* Restaurant Info */}
              {state.cartRestaurant && (
                <div className="mb-4 p-3 bg-gray-50 rounded">
                  <h6 className="fw-semibold text-gray-900 mb-0">{state.cartRestaurant.name}</h6>
                  <p className="text-gray-600 small mb-0">{state.cartRestaurant.location}</p>
                </div>
              )}

              {/* Items */}
              <div className="space-y-3 mb-4">
                {state.cart.map((item) => (
                  <div key={item.id} className="d-flex justify-content-between align-items-center">
                    <div className="flex-grow-1">
                      <div className="d-flex align-items-center gap-2">
                        <span className="fw-medium text-gray-900">{item.name}</span>
                        <span className={`small ${item.isVeg ? 'text-green-600' : 'text-red-600'}`}>
                          {item.isVeg ? '🟢' : '🔴'}
                        </span>
                      </div>
                      <span className="small text-gray-600">Qty: {item.quantity}</span>
                    </div>
                    <span className="fw-medium text-gray-900">₹{item.price * item.quantity}</span>
                  </div>
                ))}
              </div>

              {/* Bill Details */}
              <div className="space-y-2 mb-4">
                <div className="d-flex justify-content-between text-gray-600">
                  <span>Subtotal</span>
                  <span>₹{subtotal}</span>
                </div>
                <div className="d-flex justify-content-between text-gray-600">
                  <span>Delivery Fee</span>
                  <span className={deliveryFee === 0 ? 'text-green-600' : ''}>
                    {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
                  </span>
                </div>
                <div className="d-flex justify-content-between text-gray-600">
                  <span>Tax & Fees</span>
                  <span>₹{tax}</span>
                </div>
                <div className="border-top pt-2">
                  <div className="d-flex justify-content-between h5 fw-bold text-gray-900">
                    <span>Total</span>
                    <span>₹{total}</span>
                  </div>
                </div>
              </div>

              {/* Payment Method Display */}
              <div className="alert alert-info d-flex align-items-center">
                {paymentMethod === 'card' && <CreditCard className="text-primary me-2" size={20} />}
                {paymentMethod === 'upi' && <Smartphone className="text-purple-500 me-2" size={20} />}
                {paymentMethod === 'cod' && <Banknote className="text-success me-2" size={20} />}
                <span className="small fw-medium text-gray-700">
                  Payment Method: {
                    paymentMethod === 'card' ? 'Credit/Debit Card' :
                    paymentMethod === 'upi' ? 'UPI Payment' :
                    'Cash on Delivery'
                  }
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PaymentPage;