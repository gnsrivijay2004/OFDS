import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Plus, Clock, ChefHat, Filter } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import Header from '../components/Header.jsx';
import Button from '../components/Button.jsx';
import Modal from '../components/Modal.jsx';
import FormInput from '../components/FormInput.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import MenuItemCard from '../components/MenuItemCard.jsx';
import { orderService } from '../services/orderService';
import { menuService } from '../services/menuService';

function RestaurantDashboard() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [dietFilter, setDietFilter] = useState('all'); // 'all', 'veg', 'non-veg'
  const [newItem, setNewItem] = useState({
    name: '',
    isVeg: 'yes',
    price: '',
    description: ''
  });
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const currentRestaurant = state.restaurants.find(r => r.id === state.user?.id) || state.restaurants[0];

  // Fetch restaurant orders on component mount
  useEffect(() => {
    const fetchOrders = async () => {
      if (!currentRestaurant?.id) return;
      
      try {
        setLoading(true);
        const ordersData = await orderService.getRestaurantOrders(currentRestaurant.id);
        setOrders(ordersData);
      } catch (err) {
        setError('Failed to load orders. Please try again.');
        console.error('Error fetching orders:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [currentRestaurant?.id]);

  // Filter menu items based on diet preference
  const filteredMenu = currentRestaurant.menu.filter(item => {
    if (dietFilter === 'veg') return item.isVeg;
    if (dietFilter === 'non-veg') return !item.isVeg;
    return true; // 'all'
  });

  const vegCount = currentRestaurant.menu.filter(item => item.isVeg).length;
  const nonVegCount = currentRestaurant.menu.filter(item => !item.isVeg).length;

  const handleLogout = () => {
    dispatch({ type: 'LOGOUT' });
    navigate('/');
  };

  const handleAddItem = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const menuItem = {
        name: newItem.name,
        price: parseInt(newItem.price),
        isVeg: newItem.isVeg === 'yes',
        description: newItem.description,
        restaurantId: currentRestaurant.id
      };
      
      await menuService.addMenuItem(menuItem);
      
      // Refresh the restaurant data
      const updatedRestaurant = await menuService.getRestaurantMenu(currentRestaurant.id);
      dispatch({
        type: 'SET_RESTAURANTS',
        payload: state.restaurants.map(r => 
          r.id === currentRestaurant.id ? { ...r, menu: updatedRestaurant.menu } : r
        )
      });
      
      setNewItem({ name: '', isVeg: 'yes', price: '', description: '' });
      setShowAddForm(false);
    } catch (err) {
      setError('Failed to add menu item. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleEditItem = (item) => {
    setEditingItem({
      ...item,
      isVeg: item.isVeg ? 'yes' : 'no'
    });
  };

  const handleUpdateItem = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const updatedItem = {
        id: editingItem.id,
        name: editingItem.name,
        price: parseInt(editingItem.price),
        isVeg: editingItem.isVeg === 'yes',
        description: editingItem.description,
        restaurantId: currentRestaurant.id
      };
      
      await menuService.updateMenuItem(updatedItem);
      
      // Refresh the restaurant data
      const updatedRestaurant = await menuService.getRestaurantMenu(currentRestaurant.id);
      dispatch({
        type: 'SET_RESTAURANTS',
        payload: state.restaurants.map(r => 
          r.id === currentRestaurant.id ? { ...r, menu: updatedRestaurant.menu } : r
        )
      });
      
      setEditingItem(null);
    } catch (err) {
      setError('Failed to update menu item. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteItem = async (itemId) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      try {
        setLoading(true);
        await menuService.deleteMenuItem(itemId);
        
        // Refresh the restaurant data
        const updatedRestaurant = await menuService.getRestaurantMenu(currentRestaurant.id);
        dispatch({
          type: 'SET_RESTAURANTS',
          payload: state.restaurants.map(r => 
            r.id === currentRestaurant.id ? { ...r, menu: updatedRestaurant.menu } : r
          )
        });
      } catch (err) {
        setError('Failed to delete menu item. Please try again.');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      setLoading(true);
      await orderService.updateOrderStatus(orderId, newStatus);
      
      // Update local state
      setOrders(prevOrders =>
        prevOrders.map(order =>
          order.id === orderId
            ? { ...order, status: newStatus }
            : order
        )
      );
    } catch (err) {
      setError('Failed to update order status. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e, setState) => {
    setState(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-bottom">
        <div className="container-fluid">
          <div className="d-flex justify-content-between align-items-center py-3">
            <div className="d-flex align-items-center">
              <ChefHat className="text-green-500 me-3" size={32} />
              <div>
                <h1 className="h3 fw-bold text-gray-900 mb-0">{currentRestaurant.name}</h1>
                <p className="text-gray-600 mb-0">{currentRestaurant.location}</p>
              </div>
            </div>
            <Button
              onClick={handleLogout}
              variant="danger"
              icon={LogOut}
            >
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container-fluid py-4">
        {error && (
          <div className="alert alert-danger mb-4" role="alert">
            {error}
          </div>
        )}
        
        <div className="row g-4">
          {/* Orders Section */}
          <div className="col-lg-6">
            <div className="bg-white rounded-xl shadow-custom p-4">
              <h2 className="h4 fw-bold text-gray-900 mb-4 d-flex align-items-center">
                <Clock className="text-primary me-2" size={24} />
                Active Orders
              </h2>
              
              {loading && (
                <div className="text-center py-4">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <p className="mt-2 text-gray-600">Loading orders...</p>
                </div>
              )}
              
              {!loading && orders.length === 0 && (
                <div className="text-center py-4">
                  <Clock className="text-gray-400 mb-3" size={48} />
                  <p className="text-gray-600">No active orders</p>
                </div>
              )}
              
              {!loading && orders.length > 0 && (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <div key={order.id} className="border border-gray-200 rounded p-3">
                      <div className="d-flex justify-content-between align-items-start mb-3">
                        <div>
                          <h6 className="fw-semibold text-gray-900 mb-1">Order #{order.id}</h6>
                          <p className="text-gray-600 mb-0">{order.customerName}</p>
                        </div>
                        <StatusBadge status={order.status} />
                      </div>
                      <div className="mb-3">
                        <p className="small text-gray-600 mb-1">Items:</p>
                        <ul className="small text-gray-800 mb-0 ps-3">
                          {order.items.map((item, index) => (
                            <li key={index}>• {item}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="d-flex justify-content-between align-items-center">
                        <span className="fw-semibold text-green-600">₹{order.total}</span>
                        <select 
                          className="form-select form-select-sm"
                          style={{ width: 'auto' }}
                          value={order.status}
                          onChange={(e) => handleStatusChange(order.id, e.target.value)}
                        >
                          <option value="pending">Pending</option>
                          <option value="accepted">Accept</option>
                          <option value="cooking">In Cooking</option>
                          <option value="ready">Ready</option>
                          <option value="out-for-delivery">Out for Delivery</option>
                          <option value="completed">Completed</option>
                          <option value="cancelled">Cancel</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Menu Section */}
          <div className="col-lg-6">
            <div className="bg-white rounded-xl shadow-custom p-4">
              <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="h4 fw-bold text-gray-900 d-flex align-items-center mb-0">
                  <ChefHat className="text-green-500 me-2" size={24} />
                  Menu Items
                </h2>
                <Button
                  onClick={() => setShowAddForm(true)}
                  variant="success"
                  icon={Plus}
                >
                  Add Item
                </Button>
              </div>

              {/* Diet Filter */}
              <div className="d-flex align-items-center justify-content-between mb-3">
                <div className="d-flex align-items-center">
                  <Filter size={16} className="text-gray-500 me-2" />
                  <span className="small fw-medium text-gray-700">Filter:</span>
                </div>
                <div className="btn-group btn-group-sm" role="group">
                  <input 
                    type="radio" 
                    className="btn-check" 
                    name="menuFilter" 
                    id="menu-all" 
                    checked={dietFilter === 'all'}
                    onChange={() => setDietFilter('all')}
                  />
                  <label className="btn btn-outline-secondary" htmlFor="menu-all">
                    All ({currentRestaurant.menu.length})
                  </label>

                  <input 
                    type="radio" 
                    className="btn-check" 
                    name="menuFilter" 
                    id="menu-veg" 
                    checked={dietFilter === 'veg'}
                    onChange={() => setDietFilter('veg')}
                  />
                  <label className="btn btn-outline-success d-flex align-items-center" htmlFor="menu-veg">
                    <span className="bg-success rounded-circle me-1" style={{ width: '8px', height: '8px' }}></span>
                    Veg ({vegCount})
                  </label>

                  <input 
                    type="radio" 
                    className="btn-check" 
                    name="menuFilter" 
                    id="menu-non-veg" 
                    checked={dietFilter === 'non-veg'}
                    onChange={() => setDietFilter('non-veg')}
                  />
                  <label className="btn btn-outline-danger d-flex align-items-center" htmlFor="menu-non-veg">
                    <span className="bg-danger rounded-circle me-1" style={{ width: '8px', height: '8px' }}></span>
                    Non-Veg ({nonVegCount})
                  </label>
                </div>
              </div>

              <div className="space-y-4 max-h-96 overflow-y-auto">
                {filteredMenu.length === 0 ? (
                  <div className="text-center py-4">
                    <Filter size={48} className="text-gray-300 mx-auto mb-3" />
                    <h6 className="fw-semibold text-gray-700 mb-2">No items found</h6>
                    <p className="text-gray-500 mb-3">
                      No {dietFilter === 'veg' ? 'vegetarian' : 'non-vegetarian'} items in your menu
                    </p>
                    <button
                      onClick={() => setDietFilter('all')}
                      className="btn btn-link text-green-500 text-decoration-none fw-medium"
                    >
                      View all items
                    </button>
                  </div>
                ) : (
                  filteredMenu.map((item) => (
                    <MenuItemCard
                      key={item.id}
                      item={item}
                      onEdit={handleEditItem}
                      onDelete={handleDeleteItem}
                      showActions={true}
                    />
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Item Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Add New Menu Item"
      >
        <form onSubmit={handleAddItem} className="space-y-4">
          <FormInput
            label="Name"
            name="name"
            value={newItem.name}
            onChange={(e) => handleInputChange(e, setNewItem)}
            required
          />
          <div className="mb-3">
            <label className="form-label fw-medium text-gray-700">Is Veg?</label>
            <select
              name="isVeg"
              className="form-select"
              value={newItem.isVeg}
              onChange={(e) => handleInputChange(e, setNewItem)}
            >
              <option value="yes">Yes</option>
              <option value="no">No</option>
            </select>
          </div>
          <FormInput
            label="Price (₹)"
            name="price"
            type="number"
            value={newItem.price}
            onChange={(e) => handleInputChange(e, setNewItem)}
            required
          />
          <FormInput
            label="Description"
            name="description"
            type="textarea"
            value={newItem.description}
            onChange={(e) => handleInputChange(e, setNewItem)}
            required
          />
          <div className="d-flex gap-2 pt-3">
            <Button type="submit" variant="success" size="full">
              Add Item
            </Button>
            <Button 
              type="button" 
              onClick={() => setShowAddForm(false)}
              variant="ghost"
              size="full"
            >
              Cancel
            </Button>
          </div>
        </form>
      </Modal>

      {/* Edit Item Modal */}
      <Modal
        isOpen={!!editingItem}
        onClose={() => setEditingItem(null)}
        title="Edit Menu Item"
      >
        {editingItem && (
          <form onSubmit={handleUpdateItem} className="space-y-4">
            <FormInput
              label="Name"
              name="name"
              value={editingItem.name}
              onChange={(e) => handleInputChange(e, setEditingItem)}
              required
            />
            <div className="mb-3">
              <label className="form-label fw-medium text-gray-700">Is Veg?</label>
              <select
                name="isVeg"
                className="form-select"
                value={editingItem.isVeg}
                onChange={(e) => handleInputChange(e, setEditingItem)}
              >
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </div>
            <FormInput
              label="Price (₹)"
              name="price"
              type="number"
              value={editingItem.price}
              onChange={(e) => handleInputChange(e, setEditingItem)}
              required
            />
            <FormInput
              label="Description"
              name="description"
              type="textarea"
              value={editingItem.description}
              onChange={(e) => handleInputChange(e, setEditingItem)}
              required
            />
            <div className="d-flex gap-2 pt-3">
              <Button type="submit" variant="success" size="full">
                Update Item
              </Button>
              <Button 
                type="button" 
                onClick={() => setEditingItem(null)}
                variant="ghost"
                size="full"
              >
                Cancel
              </Button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}

export default RestaurantDashboard;