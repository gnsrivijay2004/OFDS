package com.ofds.menu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfdsMenuManagementApplicationTests {

	@Test
	void contextLoads() {
		//this is application test file
	}

}
