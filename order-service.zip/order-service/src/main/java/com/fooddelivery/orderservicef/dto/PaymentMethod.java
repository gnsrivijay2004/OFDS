package com.fooddelivery.orderservicef.dto;

public enum PaymentMethod {
	Card,Cash,Online

}
