
	
package com.example.payment.model;

public enum PaymentMethod {
	Card,Cash,Online

}


